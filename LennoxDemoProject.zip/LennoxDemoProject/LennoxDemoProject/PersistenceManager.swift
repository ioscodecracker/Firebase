//
//  PersistenceManager.swift
//  LennoxDemoProject
//
//  Created by vijay g on 22/12/20.
//  Copyright © 2020 developer. All rights reserved.
//

import Foundation
import CoreData

final class PersistenceManager {
    
    static let sharedInstance = PersistenceManager()
    private init() {}
    
    // MARK: - Core Data stack
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "LennoxDemoProject")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    lazy var context = persistentContainer.viewContext
    
    // MARK:  Core Data Saving support
    
    func saveContext () {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}

extension PersistenceManager {
    
    func addUser(usersDict: [String:Any], completionHandler:(Bool,Error?) -> Void) {
        let entity = NSEntityDescription.entity(forEntityName: "Users", in: context)!
        let users = NSManagedObject(entity: entity,insertInto: context)
        users.setValue(usersDict["nameStr"], forKey: "name")
        users.setValue(usersDict["emailStr"], forKey: "email")
        users.setValue(usersDict["mobileNum"], forKey: "mobileNumber")
        users.setValue(usersDict["passwordStr"], forKey: "password")
        
        do {
            try context.save()
            completionHandler(true, nil)
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
            completionHandler(false, error)
        }
    }
    
    // MARK :  Coredata Fetching Support

    func fetchUser<T:NSManagedObject>(_ entityName: String, emailId: String, mobileNumb: String, password: String) -> [T] {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetchRequest.predicate = NSPredicate(format: "mobileNumber = %@ OR  email = %@", emailId,mobileNumb)
        do {
            let fetchedObj = try context.fetch(fetchRequest) as? [T]
            return fetchedObj ?? [T]()
        } catch {
            return [T]()
        }
    }
}
