//
//  LoginViewController.swift
//  TaskApp
//
//  Created by apple on 01/10/20.
//  Copyright © 2020 apple. All rights reserved.
//

import UIKit
import Firebase

class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailidTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginBtnRef: UIButton!
    @IBOutlet weak var signUpBtnRef: UIButton!
    
       let storyBoard = UIStoryboard(name: "Main", bundle: nil)
       
       override func viewDidLoad() {
           super.viewDidLoad()
        
        // Do any additional setup after loading the view.
       }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.emailidTextField.text = ""
        self.passwordTextField.text = ""
    }
    
  
       
       
       @IBAction func loginBtnTap(_ sender: Any) {
        
        guard let emailId = emailidTextField.text else{return}
        guard let password = passwordTextField.text else{return}
        
        if !emailId.isEmpty && !password.isEmpty {
            Auth.auth().signIn(withEmail: emailId, password: password) { (result, error) in
               // guard let uid = result?.user.uid else {return}
                if let error = error {
                    self.showAlert(withTitle: "LogIn", withMessage: "\(error.localizedDescription)")
                    return
                }else{
                    let loginVC = (self.storyBoard.instantiateViewController(withIdentifier: "HomePageViewController") as? HomePageViewController)!
                    self.navigationController?.pushViewController(loginVC, animated: true)
                   
                }
            }
        }else{
            showAlert(withTitle: "LogIn", withMessage: "Please enter all fields")
        }
        
    }
       
       @IBAction func signupButtonTap(_ sender: Any) {
           let registerVC = storyBoard.instantiateViewController(withIdentifier: "SignupViewController") as? SignupViewController
           self.navigationController?.pushViewController(registerVC!, animated: true)
       }
    




}

