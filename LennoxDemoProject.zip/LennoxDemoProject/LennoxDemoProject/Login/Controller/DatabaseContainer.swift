//
//  DatabaseContainer.swift
//  LennoxDemoProject
//
//  Created by Lennox on 1/9/21.
//  Copyright © 2021 developer. All rights reserved.
//

import Foundation
import Firebase


class DatabaseContainer {
    
   static let shared = DatabaseContainer()
    
    private init(){}
    var REF: DatabaseReference!
    var REFRENCE_DATABASE = Database.database().reference()
    
}
