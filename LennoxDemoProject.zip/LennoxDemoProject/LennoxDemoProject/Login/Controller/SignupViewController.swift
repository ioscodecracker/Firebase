//
//  SignupViewController.swift
//  TaskApp
//
//  Created by apple on 01/10/20.
//  Copyright © 2020 apple. All rights reserved.
//

import UIKit
import Firebase

class SignupViewController: UIViewController {
    
    @IBOutlet weak var signUpBtnRef: UIButton!
    let storyBoard = UIStoryboard(name: "Main", bundle: nil)
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var mobileNumberTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        emailTextField.text = ""
        nameTextField.text = ""
        passwordTextField.text = ""
        mobileNumberTextField.text = ""
    }
    
    //    MARK:- Email Validations
    @IBAction func signupButtonTap(_ sender: Any) {
        
        guard let emailIdTF = emailTextField.text else{return}
        guard let nameTF = nameTextField.text else{return}
        guard let mobileTF = mobileNumberTextField.text else{return}
        guard let passwordTF = passwordTextField.text else{return}
        
        
        if !emailIdTF.isEmpty && !nameTF.isEmpty && !mobileTF.isEmpty && !passwordTF.isEmpty {
            Auth.auth().createUser(withEmail: emailIdTF, password: passwordTF) { (result, error) in
                
                let valuse = ["name" : nameTF,"emailId":emailIdTF, "password": passwordTF,"mobileNumber": mobileTF]
                
                if let error = error {
                    self.showAlert(withTitle: "SignUp", withMessage: "\(error.localizedDescription)")
                    return
                }else{
                    guard let uid = result?.user.uid else{return}
                    
                    let storeData = DatabaseContainer.shared.REFRENCE_DATABASE
                    
                    storeData.child("UserData").child(uid).setValue(valuse) { (error, res) in
                        
                        if let err = error{
                            self.showAlert(withTitle: "SignUp", withMessage: "\(err.localizedDescription)")
                            return
                        }else{
                            let loginVC = (self.storyBoard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController)!
                            self.navigationController?.pushViewController(loginVC, animated: true)
                            
                        }
                        
                    }
                    
                }
            }
        
            
        }else{
            showAlert(withTitle: "SignUp", withMessage: "Please enter all feilds")
        }
        
        
        
    }
    
   
        
    
}


