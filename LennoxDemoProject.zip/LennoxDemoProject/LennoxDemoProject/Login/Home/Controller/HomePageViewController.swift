//
//  HomePageViewController.swift
//  TaskApp
//
//  Created by apple on 01/10/20.
//  Copyright © 2020 apple. All rights reserved.
//

import UIKit
import CoreData
import Cosmos
import Firebase


class HomePageViewController: UIViewController {
    let storyBoard = UIStoryboard(name: "Main", bundle: nil)
     var window: UIWindow?
    
    var activityView = UIActivityIndicatorView(style: .large)
   
    @IBOutlet weak var ratingView: CosmosView!
    @IBOutlet weak var ratingLbl: UILabel!
    @IBOutlet weak var movieNameTextField: UITextField!
    

    @IBAction func logOutButton(_ sender: UIBarButtonItem) {
        do{
            try Auth.auth().signOut()
            navigationController?.popToRootViewController(animated: true)
        }catch let err{
           // print("DEBUG : \(err.localizedDescription)")
            
            showAlert(withTitle: "Log Out", withMessage: "\(err.localizedDescription)")
        }
    }
    @IBAction func submitButtonTapped(_ sender: UIButton) {
        guard let movieName = movieNameTextField.text, !movieName.isEmpty else{
            let alertController = UIAlertController(title: "Movie Name", message: "Please Enter a movie name", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        let alertController = UIAlertController(title: "\(movieName)", message: "\(movieName) rating is: \(self.ratingView.rating)", preferredStyle: .alert)
               alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
               alertController.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
               self.present(alertController, animated: true, completion: nil)
       
        self.ratingLbl.text = ""
        self.movieNameTextField.text = ""
        self.ratingView.rating = 0.0
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        self.ratingLbl.text = ""
        activityView.center = self.view.center
        self.view.addSubview(activityView)
        ratingView.didTouchCosmos = {rating in
            print("Ratings:-\(self.ratingView.rating)")
            self.ratingLbl.text = "\(self.ratingView.rating)"
        }
    }
}




